from pathlib import Path
import hashlib

source_dir1 = Path(r'E:\Scripts\recall_code\labelsX') # Ground truth folder
files1 = list(x for x in source_dir1.iterdir() if x.is_file())
holdx = None

source_dir2 = Path(r'E:\Scripts\recall_code\labelsY') # Detection folder
files2 = list(x for x in source_dir2.iterdir() if x.is_file())
holdy = None

condition = False
total_gt = 0
total_dt = 0
thres = 0.8
diff_lines = 0
tp = 0 #True positive
tn = 0 #True negative
fp = 0 #False positive
fn = 0 #False negative
def get_iou(bb1, bb2):
    global iou
    """
    Calculate the Intersection over Union (IoU) of two bounding boxes.

    Parameters
    ----------
    bb1 : dict
        Keys: {'x1', 'x2', 'y1', 'y2'}
        The (x1, y1) position is at the top left corner,
        the (x2, y2) position is at the bottom right corner
    bb2 : dict
        Keys: {'x1', 'x2', 'y1', 'y2'}
        The (x, y) position is at the top left corner,
        the (x2, y2) position is at the bottom right corner

    Returns
    -------
    float
        in [0, 1]
    """
    assert bb1['x1'] < bb1['x2']
    assert bb1['y1'] < bb1['y2']
    assert bb2['x1'] < bb2['x2']
    assert bb2['y1'] < bb2['y2']

    # determine the coordinates of the intersection rectangle
    classname1 = bb1['class']
    classname2 = bb2['class']
    x_left = max(bb1['x1'], bb2['x1'])
    y_top = max(bb1['y1'], bb2['y1'])
    x_right = min(bb1['x2'], bb2['x2'])
    y_bottom = min(bb1['y2'], bb2['y2'])
    if x_right < x_left or y_bottom < y_top:
        return 0.0

    # The intersection of two axis-aligned bounding boxes is always an
    # axis-aligned bounding box
    intersection_area = (x_right - x_left) * (y_bottom - y_top)
    # compute the area of both AABBs
    bb1_area = (bb1['x2'] - bb1['x1'] + 1) * (bb1['y2'] - bb1['y1'] + 1)
    bb2_area = (bb2['x2'] - bb2['x1'] + 1) * (bb2['y2'] - bb2['y1'] + 1)

    # compute the intersection over union by taking the intersection
    # area and dividing it by the sum of prediction + ground-truth
    # areas - the interesection area
    iou = intersection_area / float(bb1_area + bb2_area - intersection_area)
    assert iou >= 0.0
    assert iou <= 1.0
    return iou

for i in range(len(files1)):
    fileX = Path(files1[i])
    holdx = str(i)
    for i in range(len(files2)):
        fileY = Path(files2[i])
        holdy = str(i)
        if holdx == holdy: #If file name matches in both folders (same label .txt), then open those.
            with open(fileX) as fReaderX, open(fileY) as fReaderY:
                for lineX in fReaderX:
                    if len(lineX) != 0:
                        line_splitX = lineX.split()
                        class1 = line_splitX[0]
                        topX1 = float(line_splitX[4])
                        botX1 = float(line_splitX[6])
                        topY1 = float(line_splitX[5])
                        botY1 = float(line_splitX[7])
                        #print(line_splitX)
                        bb1 = {
                        'class' : class1,
                        'x1' : topX1,
                        'x2' : botX1,
                        'y1' : topY1,
                        'y2' : botY1,
                    }
                        if class1 == 'gun' :
                            total_gt += 1
                    else:
                        pass
                    
                    for lineY in fReaderY:
                        if len(lineY) != 0:
                            line_splitY = lineY.split()
                            class2 = line_splitY[0]
                            topX2 = float(line_splitY[4])
                            botX2 = float(line_splitY[6])
                            topY2 = float(line_splitY[5])
                            botY2 = float(line_splitY[7])
                            score = float(line_splitY[15])
                        #if len(lineY) in fileY >= 100:
                            
                            
                        bb2 = {
                        'class' : class2,
                        'x1' : topX2,
                        'x2' : botX2,
                        'y1' : topY2,
                        'y2' : botY2,
                        }
                        g_iou = get_iou(bb1, bb2)
                        print(bb2)
                            ########FOR TRUE POSITIVE######
                        if(line_splitX[0] == 'gun' and line_splitY[0] == 'gun' and g_iou>=0.15):
                            tp += 1
                        ########FOR FALSE POSITIVE######
                        if((line_splitX[0] != 'gun' and line_splitY[0] == 'gun')):
                            fp += 1
                        #    condition = True
                        elif(line_splitX[0] == 'gun' and line_splitY[0] == 'gun' and g_iou<=0.15):
                            fp += 1
                            #print(lfieX,fileY,g_iou,lineX,lineY)
                        #print(len(line_splitX))
                        ########FOR TRUE NEGATIVE######

                        if(line_splitX[0] == 'DontCare' and line_splitY[0] == 'DontCare'):
                            tn += 1
                        ########FOR TRUE NEGATIVE######
                        if(line_splitX[0] == 'gun' and line_splitY[0] != 'gun'):
                            fn += 1
                            #print(list_of_list[0][0])
                        if class2 == 'gun' :
                            total_dt += 1
                                #print(total_dt)
                        else:
                            pass
                        
                    #g_iou = get_iou(bb1, bb2)
                    #print(bb2)
                    #print(bb1)    

accuracy_ = (tp+tn)/(tp+fp+fn+tn)    
precision_ = (tp)/(tp+fp)
recall_ = (tp)/(tp+fn)
f1_ = 2*((precision_ * recall_) / (precision_ + recall_)) 



print('TOTAL GT LABELS' , total_gt)
print('TOTAL DET LABELS' , total_dt)
print('\n')  
print('TRUE POSITIVE : ' , tp)    
print('FALSE POSITIVE : ' , fp)
print('TRUE NEGATIVE : ' , tn) 
print('FALSE NEGATIVE : ' , fn)
print('\n')
print('Some metrics : ')
print('The accuracy is : ' , accuracy_)
print('The precision is : ' , precision_)
print('The recall is : ' , recall_)
print('The F1 value is : ' , f1_)