=============================
-
Recall code
-
=============================
What the code does?

This code is done to analyze models, once they have been trained we put them to test. For this, you need to separate the GT (ground truth) in labelsX folder and DET (detection) in labelsY folder.
The script examines different factors as true positives, false positives, true negatives and false negatives; as well as accuracy, precision, recall and F1.

Scripted by: Lyron and Ezequiel